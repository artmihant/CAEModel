# CAE Model
Библиотека для чтения и записи файлов форматов fc (fidesys calc) и vtu (VTU unstructed).
